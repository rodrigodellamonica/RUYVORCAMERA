package com.ruyvor.camera

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.animation.ValueAnimator
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.DashPathEffect
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.animation.LinearInterpolator
import android.graphics.Color
import android.graphics.Paint
import android.graphics.drawable.GradientDrawable
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CaptureRequest
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.util.Range
import android.view.Gravity
import android.view.OrientationEventListener
import android.view.ScaleGestureDetector
import android.view.Surface
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.camera.camera2.interop.Camera2Interop
import androidx.camera.camera2.interop.ExperimentalCamera2Interop
import androidx.camera.core.*
import androidx.camera.core.resolutionselector.AspectRatioStrategy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.*
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.ln
import kotlin.math.exp

@androidx.annotation.OptIn(ExperimentalCamera2Interop::class)
class MainActivity : AppCompatActivity() {

    private val CYAN = Color.parseColor("#00E5FF")
    private val BLUE = Color.parseColor("#0A1A33")
    private val RED = Color.parseColor("#FF2D55")

    private lateinit var previewView: PreviewView
    private lateinit var hud: TextView
    private lateinit var timerTxt: TextView
    private lateinit var panel: View
    private lateinit var shutterView: ShutterView
    private lateinit var overlay: HudOverlay
    private lateinit var flashView: View
    private lateinit var statusTxt: TextView
    private lateinit var countdownTxt: TextView
    private lateinit var timerBtn: TextView
    private lateinit var modeBtn: TextView
    private lateinit var gridView: View

    private var provider: ProcessCameraProvider? = null
    private var camera: Camera? = null
    private var imageCapture: ImageCapture? = null
    private var videoCapture: VideoCapture<Recorder>? = null
    private var recording: Recording? = null
    private var orientation: OrientationEventListener? = null

    // Configurações
    private var lensBack = true
    private var videoMode = false
    private var quality = Quality.FHD          // Full HD por padrão
    private var fps60 = false
    private var stabilization = true
    private var highRes = true                 // foto em resolução total do sensor (ex.: 50MP)
    private var manualExp = false
    private var iso = 100
    private var shutterNs = 8_333_333L          // 1/120
    private var manualFocus = false
    private var focusDiopter = 0f
    private var torch = false
    private var showGrid = true
    private var ev = 0
    private var zoomLinear = 0f

    private var recSeconds = 0
    private val handler = android.os.Handler(android.os.Looper.getMainLooper())

    // ---------- Ciclo de vida ----------
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        buildUi()
        orientation = object : OrientationEventListener(this) {
            override fun onOrientationChanged(o: Int) {
                if (o == ORIENTATION_UNKNOWN) return
                val r = when (o) {
                    in 45..134 -> Surface.ROTATION_270
                    in 135..224 -> Surface.ROTATION_180
                    in 225..314 -> Surface.ROTATION_90
                    else -> Surface.ROTATION_0
                }
                imageCapture?.targetRotation = r
                if (recording == null) videoCapture?.targetRotation = r
            }
        }
        orientation?.enable()
        askPermissions()
    }

    override fun onDestroy() {
        super.onDestroy()
        orientation?.disable()
        recording?.stop()
        countdown?.let { handler.removeCallbacks(it) }
    }

    private fun askPermissions() {
        val list = mutableListOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT <= 28) list.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        val missing = list.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isEmpty()) startCamera() else requestPermissions(missing.toTypedArray(), 10)
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) startCamera()
        else toast("Preciso da permissão da câmera")
    }

    private fun hasAudio() = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    // ---------- Características do sensor ----------
    private fun chars(): CameraCharacteristics? {
        val cm = getSystemService(CAMERA_SERVICE) as CameraManager
        val want = if (lensBack) CameraCharacteristics.LENS_FACING_BACK else CameraCharacteristics.LENS_FACING_FRONT
        for (id in cm.cameraIdList) {
            val c = cm.getCameraCharacteristics(id)
            if (c.get(CameraCharacteristics.LENS_FACING) == want) return c
        }
        return null
    }

    private fun isoRange(): Range<Int> = chars()?.get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE) ?: Range(50, 3200)
    private fun expRange(): Range<Long> = chars()?.get(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE) ?: Range(100_000L, 100_000_000L)
    private fun minFocus(): Float = chars()?.get(CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE) ?: 0f

    private fun fpsRange(): Range<Int>? {
        val target = if (fps60) 60 else 30
        val ranges = chars()?.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES) ?: return null
        return ranges.filter { it.upper == target }.maxByOrNull { it.lower }
    }

    // ---------- Câmera ----------
    private fun <T> applyOpts(b: ExtendableBuilder<T>, video: Boolean) {
        val e = Camera2Interop.Extender(b)
        if (manualExp) {
            e.setCaptureRequestOption(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_OFF)
            e.setCaptureRequestOption(CaptureRequest.SENSOR_SENSITIVITY, iso)
            e.setCaptureRequestOption(CaptureRequest.SENSOR_EXPOSURE_TIME, shutterNs)
        }
        if (manualFocus && minFocus() > 0f) {
            e.setCaptureRequestOption(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_OFF)
            e.setCaptureRequestOption(CaptureRequest.LENS_FOCUS_DISTANCE, focusDiopter)
        }
        // Foto: modos rápidos (captura instantânea). Vídeo: alta qualidade.
        e.setCaptureRequestOption(CaptureRequest.NOISE_REDUCTION_MODE,
            if (video) CaptureRequest.NOISE_REDUCTION_MODE_HIGH_QUALITY else CaptureRequest.NOISE_REDUCTION_MODE_FAST)
        e.setCaptureRequestOption(CaptureRequest.EDGE_MODE,
            if (video) CaptureRequest.EDGE_MODE_HIGH_QUALITY else CaptureRequest.EDGE_MODE_FAST)
        if (video) {
            fpsRange()?.let { e.setCaptureRequestOption(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, it) }
            if (stabilization) {
                e.setCaptureRequestOption(CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE, CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE_ON)
                e.setCaptureRequestOption(CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE, CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE_ON)
            }
        }
    }

    private fun startCamera() {
        val f = ProcessCameraProvider.getInstance(this)
        f.addListener({
            provider = f.get()
            bind()
        }, ContextCompat.getMainExecutor(this))
    }

    private fun bitrate(): Int = when (quality) {
        Quality.UHD -> if (fps60) 120_000_000 else 80_000_000
        Quality.FHD -> if (fps60) 50_000_000 else 35_000_000
        else -> if (fps60) 30_000_000 else 20_000_000
    }

    private fun bind() {
        val p = provider ?: return
        if (recording != null) return
        p.unbindAll()
        val selector = if (lensBack) CameraSelector.DEFAULT_BACK_CAMERA else CameraSelector.DEFAULT_FRONT_CAMERA

        val pb = Preview.Builder()
        applyOpts(pb, videoMode)
        if (videoMode) {
            pb.setResolutionSelector(
                ResolutionSelector.Builder()
                    .setAspectRatioStrategy(AspectRatioStrategy.RATIO_16_9_FALLBACK_AUTO_STRATEGY).build()
            )
        }
        val preview = pb.build().also { it.setSurfaceProvider(previewView.surfaceProvider) }

        try {
            if (videoMode) {
                val recorder = Recorder.Builder()
                    .setQualitySelector(QualitySelector.from(quality, FallbackStrategy.lowerQualityOrHigherThan(quality)))
                    .setTargetVideoEncodingBitRate(bitrate())
                    .build()
                val vb = VideoCapture.Builder(recorder)
                applyOpts(vb, true)
                val vcNew = vb.build()
                videoCapture = vcNew
                imageCapture = null
                camera = p.bindToLifecycle(this, selector, preview, vcNew)
            } else {
                val ib = ImageCapture.Builder()
                    .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                    .setJpegQuality(100)
                    .setResolutionSelector(
                        ResolutionSelector.Builder()
                            .setAspectRatioStrategy(AspectRatioStrategy.RATIO_4_3_FALLBACK_AUTO_STRATEGY)
                            .setResolutionStrategy(ResolutionStrategy.HIGHEST_AVAILABLE_STRATEGY)
                            .setAllowedResolutionMode(
                                if (highRes) ResolutionSelector.PREFER_HIGH_RESOLUTION_OVER_CAPTURE_RATE
                                else ResolutionSelector.PREFER_CAPTURE_RATE_OVER_HIGH_RESOLUTION
                            ).build()
                    )
                applyOpts(ib, false)
                val icNew = ib.build()
                imageCapture = icNew
                videoCapture = null
                camera = p.bindToLifecycle(this, selector, preview, icNew)
            }
        } catch (e: Exception) {
            toast("Esse aparelho não aceitou essa configuração: baixei pra automático")
            manualExp = false; manualFocus = false; fps60 = false; highRes = false
            handler.post { bind() }
            return
        }
        camera?.cameraControl?.setExposureCompensationIndex(ev.coerceIn(evRange().first, evRange().last))
        camera?.cameraControl?.enableTorch(torch)
        camera?.cameraControl?.setLinearZoom(zoomLinear)
        updateHud()
    }

    private fun evRange(): IntRange {
        val r = camera?.cameraInfo?.exposureState?.exposureCompensationRange
        return if (r == null) 0..0 else r.lower..r.upper
    }

    // ---------- Captura ----------
    private var timerSec = 0
    private var countdown: Runnable? = null
    private val tone by lazy { android.media.ToneGenerator(android.media.AudioManager.STREAM_MUSIC, 80) }

    private fun onShutter() {
        if (videoMode) { toggleRecord(); return }
        if (countdown != null) { cancelCountdown(); return }   // tocar de novo cancela
        if (timerSec <= 0) { takePhoto(); return }
        var left = timerSec
        countdownTxt.visibility = View.VISIBLE
        val r = object : Runnable {
            override fun run() {
                if (left > 0) {
                    countdownTxt.text = left.toString()
                    try { tone.startTone(android.media.ToneGenerator.TONE_PROP_BEEP, 120) } catch (e: Exception) {}
                    left--
                    handler.postDelayed(this, 1000)
                } else {
                    cancelCountdown()
                    takePhoto()
                }
            }
        }
        countdown = r
        handler.post(r)
    }

    private fun cancelCountdown() {
        countdown?.let { handler.removeCallbacks(it) }
        countdown = null
        countdownTxt.visibility = View.GONE
    }

    private fun stamp() = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())

    private fun takePhoto() {
        val ic = imageCapture ?: return
        photoFx()
        val cv = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "RUYVOR_${stamp()}")
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            if (Build.VERSION.SDK_INT >= 29) put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/RUYVORCAMERA")
        }
        val out = ImageCapture.OutputFileOptions.Builder(
            contentResolver, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv
        ).build()
        ic.takePicture(out, ContextCompat.getMainExecutor(this), object : ImageCapture.OnImageSavedCallback {
            override fun onImageSaved(r: ImageCapture.OutputFileResults) = toast("Foto salva em Pictures/RUYVORCAMERA")
            override fun onError(e: ImageCaptureException) = toast("Erro: ${e.message}")
        })
    }

    private fun toggleRecord() {
        val vc = videoCapture ?: return
        val cur = recording
        if (cur != null) { cur.stop(); return }
        val cv = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "RUYVOR_${stamp()}")
            put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
            if (Build.VERSION.SDK_INT >= 29) put(MediaStore.MediaColumns.RELATIVE_PATH, "Movies/RUYVORCAMERA")
        }
        val opts = MediaStoreOutputOptions.Builder(contentResolver, MediaStore.Video.Media.EXTERNAL_CONTENT_URI)
            .setContentValues(cv).build()
        var pr = vc.output.prepareRecording(this, opts)
        if (hasAudio()) pr = pr.withAudioEnabled()
        recording = pr.start(ContextCompat.getMainExecutor(this)) { ev ->
            if (ev is VideoRecordEvent.Finalize) {
                recording = null
                handler.removeCallbacks(ticker)
                timerTxt.visibility = View.GONE
                setRecUi(false)
                toast(if (ev.hasError()) "Erro ao gravar" else "Vídeo salvo em Movies/RUYVORCAMERA")
            }
        }
        recSeconds = 0
        timerTxt.visibility = View.VISIBLE
        setRecUi(true)
        handler.post(ticker)
    }

    private val ticker = object : Runnable {
        override fun run() {
            timerTxt.text = "● REC %02d:%02d".format(recSeconds / 60, recSeconds % 60)
            recSeconds++
            handler.postDelayed(this, 1000)
        }
    }

    private fun photoFx() {
        flashView.animate().cancel()
        flashView.alpha = 0.5f
        flashView.animate().alpha(0f).setDuration(130).start()
        previewView.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
    }

    private fun updateHud() {
        val res = when (quality) { Quality.UHD -> "4K UHD"; Quality.FHD -> "FULL HD 1080p"; else -> "HD 720p" }
        val mp = imageCapture?.resolutionInfo?.resolution?.let { "${Math.round(it.width * it.height / 1_000_000.0)}MP" } ?: "RES MAX"
        val l1 = if (videoMode) "VID // $res // ${if (fps60) 60 else 30}FPS // ${bitrate() / 1_000_000}MBPS"
                 else ("FOTO // $mp // JPEG 100 // LATENCIA MIN" + if (timerSec > 0) " // TEMP ${timerSec}S" else "")
        val l2 = StringBuilder(if (manualExp) "ISO $iso // 1/${1_000_000_000L / shutterNs}S" else "AE AUTO // EV $ev")
        l2.append(if (manualFocus) " // MF" else " // AF")
        if (stabilization && videoMode) l2.append(" // EIS")
        l2.append(if (lensBack) " // TRASEIRA" else " // FRONTAL")
        hud.text = l1 + "\n" + l2
    }

    private fun setRecUi(rec: Boolean) {
        shutterView.rec = rec
        shutterView.invalidate()
        statusTxt.text = if (rec) "● REC" else "● STBY"
        statusTxt.setTextColor(if (rec) RED else CYAN)
        modeBtn.alpha = if (rec) 0.3f else 1f
    }

    // ---------- Interface HUD futurista ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show() }

    private val GLASS = Color.parseColor("#F2040A14")
    private val DIM = Color.parseColor("#8FDFF2")

    private fun glow(fill: Int, stroke: Int, r: Int = 8) = GradientDrawable().apply {
        setColor(fill); cornerRadius = dp(r).toFloat(); setStroke(dp(1), stroke)
    }

    private fun btn(text: String, onClick: () -> Unit) = TextView(this).apply {
        this.text = text
        setTextColor(CYAN); textSize = 10f; typeface = Typeface.MONOSPACE; letterSpacing = 0.12f
        gravity = Gravity.CENTER
        setPadding(dp(4), dp(13), dp(4), dp(13))
        background = glow(Color.parseColor("#1A00E5FF"), Color.parseColor("#8800E5FF"), 6)
        setOnClickListener { onClick() }
    }

    private val chips = mutableListOf<Pair<TextView, Quality>>()
    private fun refreshChips() = chips.forEach { (v, q) ->
        val on = q == quality
        v.setTextColor(if (on) Color.BLACK else CYAN)
        v.background = glow(if (on) CYAN else Color.parseColor("#1A00E5FF"), CYAN, 6)
    }

    private fun label(t: String) = TextView(this).apply {
        text = t; setTextColor(DIM); textSize = 10f; typeface = Typeface.MONOSPACE; letterSpacing = 0.15f
        setPadding(0, dp(12), 0, dp(2))
    }

    private fun sw(label: String, init: Boolean, onChange: (Boolean) -> Unit) = SwitchCompat(this).apply {
        text = label; setTextColor(Color.WHITE); textSize = 12f; typeface = Typeface.MONOSPACE
        isChecked = init
        thumbTintList = ColorStateList.valueOf(CYAN)
        trackTintList = ColorStateList.valueOf(Color.parseColor("#4400E5FF"))
        setPadding(0, dp(6), 0, dp(6))
        setOnCheckedChangeListener { _, c -> onChange(c) }
    }

    private fun seek(max: Int, value: Int, onChange: (Int) -> Unit) = SeekBar(this).apply {
        this.max = max; progress = value
        progressTintList = ColorStateList.valueOf(CYAN)
        thumbTintList = ColorStateList.valueOf(CYAN)
        progressBackgroundTintList = ColorStateList.valueOf(Color.parseColor("#33FFFFFF"))
        setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { if (u) onChange(p) }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) { bind() }
        })
    }

    // Moldura HUD: cantos, réguas, mira central, linha de varredura, grade e retículo de foco
    inner class HudOverlay(c: Context) : View(c) {
        private val br = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = dp(2).toFloat(); color = CYAN; strokeCap = Paint.Cap.SQUARE }
        private val tick = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeWidth = 1.5f; color = Color.parseColor("#6600E5FF") }
        private val grid = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 1.2f; color = Color.parseColor("#33FFFFFF"); pathEffect = DashPathEffect(floatArrayOf(10f, 14f), 0f) }
        private val scanP = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeWidth = dp(2).toFloat(); color = Color.parseColor("#4400E5FF") }
        private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#9900E5FF"); textSize = dp(8).toFloat(); typeface = Typeface.MONOSPACE }
        private val fp = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = dp(2).toFloat(); color = Color.WHITE }
        private var scan = 0f
        private var fx = -1f; private var fy = -1f; private var fa = 0f
        private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 3800; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
            addUpdateListener { scan = it.animatedValue as Float; if (fa > 0f) fa = (fa - 0.015f).coerceAtLeast(0f); invalidate() }
        }
        override fun onAttachedToWindow() { super.onAttachedToWindow(); anim.start() }
        override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }
        fun focusAt(x: Float, y: Float) { fx = x; fy = y; fa = 1f }

        override fun onDraw(c: Canvas) {
            val w = width.toFloat(); val h = height.toFloat()
            val t = dp(112).toFloat(); val b = h - dp(160); val m = dp(14).toFloat(); val l = dp(30).toFloat()
            if (showGrid) for (i in 1..2) {
                c.drawLine(w * i / 3f, t, w * i / 3f, b, grid)
                c.drawLine(0f, t + (b - t) * i / 3f, w, t + (b - t) * i / 3f, grid)
            }
            // cantos
            c.drawLines(floatArrayOf(m, t, m + l, t, m, t, m, t + l,  w - m, t, w - m - l, t, w - m, t, w - m, t + l,
                m, b, m + l, b, m, b, m, b - l,  w - m, b, w - m - l, b, w - m, b, w - m, b - l), br)
            // réguas laterais
            var y = t + dp(40); var k = 0
            while (y < b - dp(40)) {
                val len = if (k % 5 == 0) dp(12).toFloat() else dp(6).toFloat()
                c.drawLine(m, y, m + len, y, tick); c.drawLine(w - m, y, w - m - len, y, tick)
                y += dp(10); k++
            }
            // mira central
            val cx = w / 2f; val cy = (t + b) / 2f; val r = dp(16).toFloat()
            c.drawCircle(cx, cy, r, tick); c.drawCircle(cx, cy, dp(2).toFloat(), br)
            c.drawLines(floatArrayOf(cx - r - dp(10), cy, cx - r, cy, cx + r, cy, cx + r + dp(10), cy,
                cx, cy - r - dp(10), cx, cy - r, cx, cy + r, cx, cy + r + dp(10)), br)
            // varredura
            val sy = t + (b - t) * scan
            c.drawLine(m, sy, w - m, sy, scanP)
            // rótulos
            c.drawText("SYS.ONLINE", m + dp(4), t - dp(5), txt)
            val tag = "SENSOR.LINK"
            c.drawText(tag, w - m - dp(4) - txt.measureText(tag), t - dp(5), txt)
        }
    }

    // Botão disparador: anel segmentado girando
    inner class ShutterView(c: Context) : View(c) {
        var rec = false
        var video = false
        private var rot = 0f
        private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = dp(3).toFloat(); color = CYAN; strokeCap = Paint.Cap.ROUND }
        private val thin = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = dp(1).toFloat(); color = Color.parseColor("#6600E5FF") }
        private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
        private val anim = ValueAnimator.ofFloat(0f, 360f).apply {
            duration = 6000; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
            addUpdateListener { rot = it.animatedValue as Float; invalidate() }
        }
        override fun onAttachedToWindow() { super.onAttachedToWindow(); anim.start() }
        override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }
        override fun onDraw(c: Canvas) {
            val cx = width / 2f; val cy = height / 2f; val rr = minOf(cx, cy) - dp(4)
            val o = RectF(cx - rr, cy - rr, cx + rr, cy + rr)
            c.save(); c.rotate(rot, cx, cy)
            for (i in 0 until 10) c.drawArc(o, i * 36f + 4f, 24f, false, ring)
            c.restore()
            val r2 = rr - dp(8)
            c.drawCircle(cx, cy, r2, thin)
            val ri = r2 - dp(7)
            if (rec) {
                fill.shader = null; fill.color = RED
                c.drawRoundRect(cx - ri * 0.6f, cy - ri * 0.6f, cx + ri * 0.6f, cy + ri * 0.6f, dp(6).toFloat(), dp(6).toFloat(), fill)
            } else {
                val cols = if (video) intArrayOf(Color.parseColor("#FF8095"), RED) else intArrayOf(Color.WHITE, Color.parseColor("#7FEFFF"))
                fill.shader = RadialGradient(cx, cy, ri, cols, null, Shader.TileMode.CLAMP)
                c.drawCircle(cx, cy, ri, fill)
            }
        }
    }

    private fun buildUi() {
        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        val mp = ViewGroup.LayoutParams.MATCH_PARENT

        previewView = PreviewView(this).apply { scaleType = PreviewView.ScaleType.FIT_CENTER }
        root.addView(previewView, mp, mp)
        overlay = HudOverlay(this); gridView = overlay
        root.addView(overlay, mp, mp)
        flashView = View(this).apply { setBackgroundColor(Color.WHITE); alpha = 0f }
        root.addView(flashView, mp, mp)

        // Zoom por pinça + toque pra focar
        val sd = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(d: ScaleGestureDetector): Boolean {
                val z = camera?.cameraInfo?.zoomState?.value?.zoomRatio ?: 1f
                camera?.cameraControl?.setZoomRatio(z * d.scaleFactor)
                return true
            }
        })
        previewView.setOnTouchListener { v, e ->
            sd.onTouchEvent(e)
            if (e.action == MotionEvent.ACTION_UP && e.pointerCount == 1 && !sd.isInProgress) {
                val pt = previewView.meteringPointFactory.createPoint(e.x, e.y)
                camera?.cameraControl?.startFocusAndMetering(FocusMeteringAction.Builder(pt).build())
                overlay.focusAt(e.x, e.y)
                v.performClick()
            }
            true
        }

        // Topo
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(30), dp(16), dp(18))
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(Color.parseColor("#F2040A14"), Color.TRANSPARENT))
        }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val title = TextView(this).apply {
            text = "RUYVOR//CAM"; setTextColor(CYAN); textSize = 16f
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD); letterSpacing = 0.2f
        }
        statusTxt = TextView(this).apply {
            text = "● STBY"; setTextColor(CYAN); textSize = 11f; typeface = Typeface.MONOSPACE; letterSpacing = 0.15f
        }
        row.addView(title, LinearLayout.LayoutParams(0, -2, 1f)); row.addView(statusTxt)
        hud = TextView(this).apply {
            setTextColor(DIM); textSize = 10f; typeface = Typeface.MONOSPACE; letterSpacing = 0.06f
            setPadding(0, dp(6), 0, 0)
        }
        top.addView(row); top.addView(hud)
        root.addView(top, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))

        timerTxt = TextView(this).apply {
            setTextColor(RED); textSize = 15f; typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
            letterSpacing = 0.12f; visibility = View.GONE
            setPadding(dp(14), dp(6), dp(14), dp(6))
            background = glow(Color.parseColor("#CC040A14"), RED, 20)
        }
        root.addView(timerTxt, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { topMargin = dp(124) })

        // Base
        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), dp(36), dp(10), dp(26))
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(Color.TRANSPARENT, Color.parseColor("#F2040A14")))
        }
        val lp = { LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(4), 0, dp(4), 0) } }
        val cfg = btn("AJUSTES") { panel.visibility = if (panel.visibility == View.VISIBLE) View.GONE else View.VISIBLE }
        val flash = btn("TOCHA") { torch = !torch; camera?.cameraControl?.enableTorch(torch) }
        modeBtn = btn("FOTO") {
            if (recording == null) {
                videoMode = !videoMode
                modeBtn.text = if (videoMode) "VÍDEO" else "FOTO"
                shutterView.video = videoMode; shutterView.invalidate()
                timerBtn.visibility = if (videoMode) View.GONE else View.VISIBLE
                cancelCountdown()
                bind()
            }
        }
        val flip = btn("VIRAR") { lensBack = !lensBack; bind(); refreshSliders() }

        shutterView = ShutterView(this)
        shutterView.setOnTouchListener { v, e ->
            if (e.action == MotionEvent.ACTION_DOWN) {
                onShutter()   // dispara no toque, sem esperar soltar
                v.animate().scaleX(0.88f).scaleY(0.88f).setDuration(40).withEndAction {
                    v.animate().scaleX(1f).scaleY(1f).setDuration(90).start()
                }.start()
            }
            true
        }
        bottom.addView(cfg, lp()); bottom.addView(flash, lp())
        bottom.addView(shutterView, LinearLayout.LayoutParams(dp(84), dp(84)).apply { setMargins(dp(6), 0, dp(6), 0) })
        bottom.addView(modeBtn, lp()); bottom.addView(flip, lp())
        root.addView(bottom, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))

        // Temporizador (só no modo foto): DESLIGADO -> 3s -> 5s -> 10s
        timerBtn = btn("TEMPORIZADOR: OFF") {
            val opts = intArrayOf(0, 3, 5, 10)
            timerSec = opts[(opts.indexOf(timerSec) + 1) % opts.size]
            timerBtn.text = if (timerSec == 0) "TEMPORIZADOR: OFF" else "TEMPORIZADOR: ${timerSec}S"
            updateHud()
        }
        timerBtn.setPadding(dp(14), dp(8), dp(14), dp(8))
        root.addView(timerBtn, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.START).apply {
            setMargins(dp(14), 0, 0, dp(158))
        })

        countdownTxt = TextView(this).apply {
            setTextColor(CYAN); textSize = 120f; typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
            setShadowLayer(30f, 0f, 0f, CYAN); visibility = View.GONE
        }
        root.addView(countdownTxt, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))

        // Painel de ajustes
        val sv = ScrollView(this).apply {
            visibility = View.GONE
            background = glow(GLASS, Color.parseColor("#9900E5FF"), 14)
        }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(10), dp(16), dp(16)) }
        sv.addView(col)
        panel = sv
        col.addView(TextView(this).apply {
            text = "// PARÂMETROS DO SISTEMA"; setTextColor(CYAN); textSize = 12f
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD); letterSpacing = 0.15f
            setPadding(0, dp(6), 0, dp(2))
        })
        buildPanel(col)
        root.addView(sv, FrameLayout.LayoutParams(-1, dp(380), Gravity.BOTTOM).apply {
            setMargins(dp(10), 0, dp(10), dp(150))
        })

        setContentView(root)
    }

    private var isoBar: SeekBar? = null
    private var shBar: SeekBar? = null
    private var fcBar: SeekBar? = null

    private fun refreshSliders() {
        handler.postDelayed({
            val ir = isoRange(); val er = expRange()
            isoBar?.progress = ((iso - ir.lower).toFloat() / (ir.upper - ir.lower) * 1000).toInt().coerceIn(0, 1000)
            shBar?.progress = (ln(shutterNs.toDouble() / er.lower.toDouble()) / ln(er.upper.toDouble() / er.lower.toDouble()) * 1000).toInt().coerceIn(0, 1000)
        }, 400)
    }

    private fun buildPanel(col: LinearLayout) {
        col.addView(label("RESOLUÇÃO DE VÍDEO"))
        val rg = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("HD" to Quality.HD, "FULL HD" to Quality.FHD, "4K" to Quality.UHD).forEach { (n, q) ->
            val chip = btn(n) { if (recording == null) { quality = q; refreshChips(); bind() } }
            chips.add(chip to q)
            rg.addView(chip, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(3), 0, dp(3), 0) })
        }
        col.addView(rg)
        refreshChips()

        col.addView(sw("60 FPS (se o aparelho aceitar)", fps60) { fps60 = it; bind() })
        col.addView(sw("Estabilização de vídeo", stabilization) { stabilization = it; bind() })
        col.addView(sw("Grade HUD", showGrid) { showGrid = it; gridView.invalidate() })

        col.addView(sw("Exposição manual (ISO + obturador)", manualExp) { manualExp = it; bind() })
        col.addView(label("ISO"))
        val isoSeek = seek(1000, 100) { p ->
            val r = isoRange(); iso = r.lower + (p / 1000f * (r.upper - r.lower)).toInt(); updateHud()
        }
        isoBar = isoSeek
        col.addView(isoSeek)
        col.addView(label("OBTURADOR"))
        val shSeek = seek(1000, 500) { p ->
            val r = expRange()
            val lo = r.lower.toLong(); val hi = r.upper.toLong()
            shutterNs = (lo * exp(p / 1000.0 * ln(hi.toDouble() / lo.toDouble()))).toLong().coerceIn(lo, hi)
            updateHud()
        }
        shBar = shSeek
        col.addView(shSeek)

        col.addView(sw("Foco manual", manualFocus) { manualFocus = it; bind() })
        col.addView(label("FOCO (perto ←→ longe)"))
        val fcSeek = seek(1000, 1000) { p ->
            focusDiopter = minFocus() * (1f - p / 1000f); updateHud()
        }
        fcBar = fcSeek
        col.addView(fcSeek)

        col.addView(label("EXPOSIÇÃO (EV)"))
        col.addView(seek(100, 50) { p ->
            val r = evRange()
            ev = if (r.last == 0) 0 else (r.first + (p / 100f * (r.last - r.first))).toInt()
            camera?.cameraControl?.setExposureCompensationIndex(ev); updateHud()
        })

        col.addView(label("ZOOM"))
        col.addView(seek(100, 0) { p ->
            zoomLinear = p / 100f; camera?.cameraControl?.setLinearZoom(zoomLinear)
        })
    }
}
