package com.ruyvor.camera

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.ImageFormat
import android.graphics.Rect
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CameraMetadata
import android.hardware.camera2.CaptureFailure
import android.hardware.camera2.CaptureRequest
import android.hardware.camera2.CaptureResult
import android.hardware.camera2.TotalCaptureResult
import android.hardware.camera2.params.OutputConfiguration
import android.hardware.camera2.params.SessionConfiguration
import android.media.ImageReader
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.util.Size
import java.util.concurrent.Executor

/**
 * Captura de foto em resolução TOTAL do sensor (ex.: 50MP) direto pela Camera2.
 *
 * O CameraX só enxerga as resoluções "normais" (pixel binning, ~12MP). O modo de sensor total
 * (SENSOR_PIXEL_MODE_MAXIMUM_RESOLUTION) só é acessível pela Camera2, então este motor:
 *  1) varre TODAS as resoluções JPEG que o aparelho libera (normal, alta e sensor total);
 *  2) abre a câmera, deixa foco e exposição convergirem e tira a foto na maior resolução;
 *  3) devolve os bytes do JPEG para o app salvar.
 */
class Camera2Still(ctx: Context) {

    class Pick(val id: String, val size: Size, val maxRes: Boolean) {
        val area: Long get() = size.width.toLong() * size.height
        val mp: Int get() = Math.round(area / 1_000_000.0).toInt()
    }

    class Params(
        val zoom: Float,
        val ev: Int,
        val torch: Boolean,
        val manualExp: Boolean,
        val iso: Int,
        val shutterNs: Long,
        val manualFocus: Boolean,
        val focusDiopter: Float,
        val deviceDegrees: Int
    )

    private val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
    @Volatile private var busy = false

    // ---------- Descoberta de resoluções ----------
    private fun facingOk(c: CameraCharacteristics, back: Boolean): Boolean {
        val f = c.get(CameraCharacteristics.LENS_FACING) ?: return false
        return f == (if (back) CameraCharacteristics.LENS_FACING_BACK else CameraCharacteristics.LENS_FACING_FRONT)
    }

    private fun compat(c: CameraCharacteristics): Boolean {
        val caps = c.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES) ?: return true
        return caps.contains(CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_BACKWARD_COMPATIBLE)
    }

    fun candidates(back: Boolean): List<Pick> {
        val out = ArrayList<Pick>()
        try {
            for (id in cm.cameraIdList) {
                val c = cm.getCameraCharacteristics(id)
                if (!facingOk(c, back) || !compat(c)) continue
                val map = c.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
                if (map != null) {
                    map.getOutputSizes(ImageFormat.JPEG)?.forEach { out.add(Pick(id, it, false)) }
                    map.getHighResolutionOutputSizes(ImageFormat.JPEG)?.forEach { out.add(Pick(id, it, false)) }
                }
                if (Build.VERSION.SDK_INT >= 33) {
                    val mm = c.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP_MAXIMUM_RESOLUTION)
                    if (mm != null) {
                        mm.getOutputSizes(ImageFormat.JPEG)?.forEach { out.add(Pick(id, it, true)) }
                        mm.getHighResolutionOutputSizes(ImageFormat.JPEG)?.forEach { out.add(Pick(id, it, true)) }
                    }
                }
            }
        } catch (e: Exception) { /* segue com o que achou */ }
        return out
    }

    /** Maior resolução liberada; em empate prefere o modo normal (mais rápido). */
    fun bestSize(back: Boolean): Pick? =
        candidates(back).maxWithOrNull(compareBy<Pick>({ it.area }, { if (it.maxRes) 0 else 1 }))

    fun report(back: Boolean): String {
        val l = candidates(back)
        if (l.isEmpty()) return "SEM DADOS DO SENSOR"
        val n = l.filter { !it.maxRes }.maxByOrNull { it.area }
        val m = l.filter { it.maxRes }.maxByOrNull { it.area }
        val a = if (n != null) "NORMAL ${n.size.width}x${n.size.height} (${n.mp}MP)" else "NORMAL N/D"
        val b = if (m != null) "SENSOR TOTAL ${m.size.width}x${m.size.height} (${m.mp}MP)" else "SENSOR TOTAL N/D"
        return "$a\n$b"
    }

    // ---------- Captura ----------
    fun capture(pick: Pick, p: Params, done: (ByteArray?, String?) -> Unit) {
        if (busy) { done(null, "câmera ocupada"); return }
        busy = true
        val ht = HandlerThread("ruyvor-still").also { it.start() }
        val h = Handler(ht.looper)
        try {
            Job(pick, p, h, ht) { bytes, err -> busy = false; done(bytes, err) }.start()
        } catch (e: Exception) {
            busy = false
            ht.quitSafely()
            done(null, e.message ?: "falha ao iniciar")
        }
    }

    private inner class Job(
        val pick: Pick,
        val p: Params,
        val h: Handler,
        val ht: HandlerThread,
        val finish: (ByteArray?, String?) -> Unit
    ) {
        @Volatile private var finished = false
        private var device: CameraDevice? = null
        private var session: CameraCaptureSession? = null
        private var jpegReader: ImageReader? = null
        private var smallReader: ImageReader? = null
        private var retries = 4
        private val exec = Executor { r -> h.post(r) }
        private val chars: CameraCharacteristics = cm.getCameraCharacteristics(pick.id)

        fun start() {
            h.postDelayed({ end(null, "tempo esgotado") }, 14000)
            h.postDelayed({ open() }, 350)   // dá tempo do CameraX liberar a câmera
        }

        @SuppressLint("MissingPermission")
        private fun open() {
            if (finished) return
            try {
                cm.openCamera(pick.id, object : CameraDevice.StateCallback() {
                    override fun onOpened(d: CameraDevice) {
                        if (finished) { d.close(); return }
                        device = d
                        makeSession(d)
                    }
                    override fun onDisconnected(d: CameraDevice) {
                        d.close()
                        if (device != null) end(null, "câmera desconectada") else retryOrFail("câmera desconectada")
                    }
                    override fun onError(d: CameraDevice, e: Int) {
                        d.close()
                        if (device != null) end(null, "erro da câmera ($e)") else retryOrFail("câmera em uso ($e)")
                    }
                }, h)
            } catch (e: Exception) {
                retryOrFail(e.message ?: "falha ao abrir a câmera")
            }
        }

        private fun retryOrFail(msg: String) {
            if (finished) return
            if (retries-- > 0) h.postDelayed({ open() }, 300) else end(null, msg)
        }

        private fun makeSession(d: CameraDevice) {
            try {
                val map = chars.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)!!
                val smallSize = map.getOutputSizes(ImageFormat.YUV_420_888)
                    ?.filter { it.width.toLong() * it.height <= 1_000_000L }
                    ?.maxByOrNull { it.width.toLong() * it.height } ?: Size(640, 480)
                val jr = ImageReader.newInstance(pick.size.width, pick.size.height, ImageFormat.JPEG, 2)
                val sr = ImageReader.newInstance(smallSize.width, smallSize.height, ImageFormat.YUV_420_888, 2)
                sr.setOnImageAvailableListener({ r ->
                    try { r.acquireLatestImage()?.close() } catch (e: Exception) { }
                }, h)
                jpegReader = jr
                smallReader = sr

                val cb = object : CameraCaptureSession.StateCallback() {
                    override fun onConfigured(s: CameraCaptureSession) {
                        if (finished) { s.close(); return }
                        session = s
                        converge()
                    }
                    override fun onConfigureFailed(s: CameraCaptureSession) {
                        end(null, "o aparelho recusou essa resolução")
                    }
                }
                if (Build.VERSION.SDK_INT >= 28) {
                    val oj = OutputConfiguration(jr.surface)
                    if (pick.maxRes && Build.VERSION.SDK_INT >= 33) {
                        oj.addSensorPixelModeUsed(CameraMetadata.SENSOR_PIXEL_MODE_MAXIMUM_RESOLUTION)
                    }
                    val os = OutputConfiguration(sr.surface)
                    d.createCaptureSession(SessionConfiguration(SessionConfiguration.SESSION_REGULAR, listOf(os, oj), exec, cb))
                } else {
                    @Suppress("DEPRECATION")
                    d.createCaptureSession(listOf(sr.surface, jr.surface), cb, h)
                }
            } catch (e: Exception) {
                end(null, e.message ?: "falha ao criar a sessão")
            }
        }

        // ---------- Parâmetros comuns ----------
        private fun crop(forMax: Boolean): Rect? {
            if (p.zoom <= 1.01f) return null
            var arr: Rect? = null
            if (forMax && Build.VERSION.SDK_INT >= 31) {
                arr = chars.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE_MAXIMUM_RESOLUTION)
            }
            if (arr == null) arr = chars.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE)
            if (arr == null) return null
            val w = (arr.width() / p.zoom).toInt()
            val hh = (arr.height() / p.zoom).toInt()
            val l = arr.left + (arr.width() - w) / 2
            val t = arr.top + (arr.height() - hh) / 2
            return Rect(l, t, l + w, t + hh)
        }

        private fun baseSet(b: CaptureRequest.Builder, forMax: Boolean) {
            if (p.manualExp) {
                b.set(CaptureRequest.CONTROL_AE_MODE, CameraMetadata.CONTROL_AE_MODE_OFF)
                b.set(CaptureRequest.SENSOR_SENSITIVITY, p.iso)
                b.set(CaptureRequest.SENSOR_EXPOSURE_TIME, p.shutterNs)
            } else {
                b.set(CaptureRequest.CONTROL_AE_MODE, CameraMetadata.CONTROL_AE_MODE_ON)
                val r = chars.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_RANGE)
                val ev = if (r != null) p.ev.coerceIn(r.lower, r.upper) else 0
                b.set(CaptureRequest.CONTROL_AE_EXPOSURE_COMPENSATION, ev)
            }
            val minF = chars.get(CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE) ?: 0f
            val afModes = chars.get(CameraCharacteristics.CONTROL_AF_AVAILABLE_MODES)
            if (p.manualFocus && minF > 0f) {
                b.set(CaptureRequest.CONTROL_AF_MODE, CameraMetadata.CONTROL_AF_MODE_OFF)
                b.set(CaptureRequest.LENS_FOCUS_DISTANCE, p.focusDiopter)
            } else if (afModes?.contains(CameraMetadata.CONTROL_AF_MODE_CONTINUOUS_PICTURE) == true) {
                b.set(CaptureRequest.CONTROL_AF_MODE, CameraMetadata.CONTROL_AF_MODE_CONTINUOUS_PICTURE)
            }
            if (p.torch) b.set(CaptureRequest.FLASH_MODE, CameraMetadata.FLASH_MODE_TORCH)
            crop(forMax)?.let { b.set(CaptureRequest.SCALER_CROP_REGION, it) }
        }

        // ---------- Foco e exposição convergem na stream pequena ----------
        private fun converge() {
            val s = session ?: return
            val d = device ?: return
            try {
                val rb = d.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW)
                rb.addTarget(smallReader!!.surface)
                baseSet(rb, false)
                val started = System.currentTimeMillis()
                s.setRepeatingRequest(rb.build(), object : CameraCaptureSession.CaptureCallback() {
                    var frames = 0
                    var fired = false
                    override fun onCaptureCompleted(ss: CameraCaptureSession, r: CaptureRequest, res: TotalCaptureResult) {
                        if (fired || finished) return
                        frames++
                        val af = res.get(CaptureResult.CONTROL_AF_STATE)
                        val ae = res.get(CaptureResult.CONTROL_AE_STATE)
                        val afOk = p.manualFocus || af == null ||
                            af == CaptureResult.CONTROL_AF_STATE_PASSIVE_FOCUSED ||
                            af == CaptureResult.CONTROL_AF_STATE_FOCUSED_LOCKED ||
                            af == CaptureResult.CONTROL_AF_STATE_NOT_FOCUSED_LOCKED ||
                            af == CaptureResult.CONTROL_AF_STATE_PASSIVE_UNFOCUSED
                        val aeOk = p.manualExp || ae == null ||
                            ae == CaptureResult.CONTROL_AE_STATE_CONVERGED ||
                            ae == CaptureResult.CONTROL_AE_STATE_LOCKED ||
                            ae == CaptureResult.CONTROL_AE_STATE_FLASH_REQUIRED
                        val timeout = System.currentTimeMillis() - started > 1500
                        if ((frames >= 4 && afOk && aeOk) || (frames >= 2 && timeout)) {
                            fired = true
                            h.post { shoot() }
                        }
                    }
                }, h)
            } catch (e: Exception) {
                end(null, e.message ?: "falha ao ajustar foco")
            }
        }

        private fun jpegOrientation(): Int {
            val sensor = chars.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 90
            val dev = ((p.deviceDegrees + 45) / 90 * 90) % 360
            val front = chars.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_FRONT
            return if (front) (sensor + dev) % 360 else (sensor - dev + 360) % 360
        }

        // ---------- Disparo na resolução máxima ----------
        private fun shoot() {
            val s = session ?: return
            val d = device ?: return
            val jr = jpegReader ?: return
            if (finished) return
            try {
                try { s.stopRepeating() } catch (e: Exception) { }
                jr.setOnImageAvailableListener({ r ->
                    try {
                        val img = r.acquireNextImage()
                        if (img != null) {
                            val buf = img.planes[0].buffer
                            val bytes = ByteArray(buf.remaining())
                            buf.get(bytes)
                            img.close()
                            end(bytes, null)
                        }
                    } catch (e: Exception) {
                        end(null, e.message ?: "falha ao ler a imagem")
                    }
                }, h)
                val cb = d.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE)
                cb.addTarget(jr.surface)
                baseSet(cb, pick.maxRes)
                cb.set(CaptureRequest.JPEG_QUALITY, 100.toByte())
                cb.set(CaptureRequest.JPEG_ORIENTATION, jpegOrientation())
                if (pick.maxRes && Build.VERSION.SDK_INT >= 31) {
                    cb.set(CaptureRequest.SENSOR_PIXEL_MODE, CameraMetadata.SENSOR_PIXEL_MODE_MAXIMUM_RESOLUTION)
                }
                s.capture(cb.build(), object : CameraCaptureSession.CaptureCallback() {
                    override fun onCaptureFailed(ss: CameraCaptureSession, r: CaptureRequest, f: CaptureFailure) {
                        end(null, "a captura falhou")
                    }
                }, h)
            } catch (e: Exception) {
                end(null, e.message ?: "falha ao capturar")
            }
        }

        fun end(bytes: ByteArray?, err: String?) {
            if (finished) return
            finished = true
            try { session?.close() } catch (e: Exception) { }
            try { device?.close() } catch (e: Exception) { }
            try { jpegReader?.close() } catch (e: Exception) { }
            try { smallReader?.close() } catch (e: Exception) { }
            ht.quitSafely()
            finish(bytes, err)
        }
    }
}
